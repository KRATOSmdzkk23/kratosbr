const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
         〘 𝙈𝙄𝘿𝙊𝙍𝙄𝙔𝘼 𝘽𝙊𝙏🧸 〙

    ➣ 𝙎𝘼𝙇𝙑𝙀!!!! ${pushname}️
    ➣ 𝙓𝙋🔥: ${reqXp} 
    ➣𝙈𝙤𝙣𝙚𝙮☔: ${uangku}
    
       〘 𝙍𝙀𝘿𝙀𝙎 𝙎𝙊𝘾𝙄𝘼𝙄𝙎 🍷〙

║  ➣𝙂𝙍𝙐𝙋𝙊 𝘿𝙊 𝙒𝙋𝙋:https://suaurl.com/ed293b
║  ➣𝘾𝘼𝙉𝘼𝙇 𝘿𝙊 𝘾𝙍𝙄𝘼𝘿𝙊𝙍:https://suaurl.com/1efa08
║  
║ ➣〘 𝙄𝙣𝙛𝙤𝙧𝙢𝙖𝙘̧𝙤̃𝙚𝙨 〙
║ ➥ wa.me/558694292223
║ ➥ Prefix: 「  ${prefix}  」
║ ➥Criador: Kratos🧸
║ ➥Faça Uma doação via pix!
║ (chave pix) 428a13b4-c812-45f8-a516-8e74781797d3
║ ➥𝙉𝙞𝙫𝙚𝙡 𝙙𝙚 𝘿𝙤𝙖𝙘̧𝙤̃𝙚𝙨 0.00$🙂
║
║ ➣𝙈𝙀𝙉𝙐 𝙂𝙀𝙍𝘼𝙇!!📚
║
║ 
║ ➣ 〘𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 𝙎𝙄𝙈𝙋𝙇𝙀𝙎 𝘿𝙊 𝘽𝙊𝙏🤖〙
║
║ ➥ ${prefix}limite (ver seu limite)
║ ➥ ${prefix}buylimite (comprar limite)
║ ➥ ${prefix}bal (ver seu dinheiro)
║ ➥Aumente seu level interagindo no grupo!!
║ ➥ ${prefix}
║ ➣〘𝙊𝙐𝙏𝙍𝙊𝙎 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎🧸〙
║  
║ ➥ ${prefix}info
║ ➥ ${prefix}blocklist
║ ➥ ${prefix}chatlist
║ ➥ ${prefix}ping
║ ➥ ${prefix}bugreport
║
║➣ 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 𝘿𝙀 𝙁𝙄𝙂𝙐𝙍𝙄𝙉𝙃𝘼𝙎🛹
║ ➥ ${prefix}figu
║ ➥ ${prefix}toimg
║ ➥ ${prefix}virarmp3
║ ➥ ${prefix}shadow
║ ➥ ${prefix}burnpaper
║ ➥ ${prefix}coffee
║ ➥ ${prefix}lovepaper
║ ➥ ${prefix}calunia
║ ➥ ${prefix}shota
║
║ ➣ 〘𝙈𝙀𝘿𝙄𝘼🪀〙
║ 
║ ➥ ${prefix}trendtwit
║ ➥ ${prefix}randomkpop
║ ➥ ${prefix}ytsearch
║ ➣ 𝙁𝘼𝙇𝘼 𝘾𝙊𝙈 𝙊 𝘽𝙊𝙏🍂  
║
║ ➥ ${prefix}avalie
║ ➣  〘𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿⬇️〙 
║  
║ ➥ ${prefix}images
║ ➥ ${prefix}ytmp3
║ ➥ ${prefix}ytmp4
║ ➥ ${prefix}tiktok
║ ➥ ${prefix}joox
║ ➣ 〘𝙈𝙀𝙈𝙀𝙎🤣〙
║  
║ ➥ ${prefix}meme
║ ➥ ${prefix}memeindo
║
║ 〘𝙎𝙊𝙈❕〙
║  
║ ➥ ${prefix}musica
║ ➥ ${prefix}audio
║ 〘𝙈𝙐𝙎𝙄𝘾𝘼𝙎⬇️〙
║  
║ ➥ ${prefix}lirik
║ ➥ ${prefix}chord
║ ➥ 𝙎𝙏𝘼𝙍𝙆𝙀𝘼𝙍
║ 
║ ➥ ${prefix}tiktokstalk
║ ➥ ${prefix}igstalk
║ 𝘼𝙉𝙄𝙈𝙀𝙎🦸
  
║ ➥ ${prefix}neonime
║ ➥ ${prefix}pokemon
║ ➥ ${prefix}loli
║ ➥ ${prefix}waifu
║ ➥ ${prefix}randomanime
║ ➥ ${prefix}husbu
║ ➥ ${prefix}husbu2
║ ➥ ${prefix}buscanime
║ ➥ ${prefix}nekonime
║ 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 𝘿𝙀 𝙑𝙊𝙕🍇
║
║ ➥ ${prefix}bahasa
║
║  𝘿𝙊𝙉𝙊😎 
║ ➥ ${prefix}setprefix
║ ➥ ${prefix}block
║ ➥ ${prefix}tm
║ ➥ ${prefix}tmctt
║ ➥ ${prefix}clone
║ ➥ ${prefix}clearall
║
║ 𝘿𝙞𝙫𝙚𝙧𝙨𝙖̃𝙤🤣
║
║ ➥ ${prefix}lgbt
║ ➥ ${prefix}gay
║ ➥ ${prefix}gay2
║ ➥ ${prefix}gado
║ ➥ ${prefix}buc
║ 𝙐𝙇𝙏𝙄𝙈𝙊𝙎 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎😋
║ 
║ ➥ ${prefix}send
║ ➥ ${prefix}wame
║ ➥ ${prefix}virtex
║ ➥ ${prefix}exe
║ ➥ ${prefix}qrcode
║ ➥ ${prefix}afk
║ ➥ ${prefix}timer
║ ➥ ${prefix}fml
║ ➥ ${prefix}fml2
`
}
exports.help = help
